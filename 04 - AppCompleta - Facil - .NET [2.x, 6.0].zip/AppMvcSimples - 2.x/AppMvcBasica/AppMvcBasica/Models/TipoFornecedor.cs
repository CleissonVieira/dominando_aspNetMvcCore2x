﻿namespace AppMvcBasica.Models
{
    public enum TipoFornecedor
    {
        PessoaFisica = 1,
        PessoaJuridica
    }
}